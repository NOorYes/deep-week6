template <typename T>
class VectorT2D
{
private:
	T x_, y_;
};


class VectorInt2D
{
	int x_, y_;
};

class VectorFloat2D
{
	float x_, y_;
};

class VectorDouble2D
{
	double x_, y_;
};